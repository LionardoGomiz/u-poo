
package rombos;

import java.util.Scanner;

public class Figura3 {
    public static void main(String[] args) {
        int tam, c, f;
        System.out.println("¿De que tamaño quiere que sea la figura?");
        Scanner entrada = new Scanner(System.in);
        tam = entrada.nextInt();
        f = 0;
        while (f < tam){
            c = 0;
            while (c <= f){
                System.out.print(" ");
                c = c + 1;
            }
            c = tam - f;
            while (c >= 1){
                System.out.print("*");
                c = c - 1;
            }
            System.out.println("");
            f = f + 1;
        } 
    }
}
